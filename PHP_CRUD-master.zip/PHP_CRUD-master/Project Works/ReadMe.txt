PHP CRUD BASIC WEB APPLICATION

SQL Folder Contain the importable SQL file, Use it When you want to import data table.
Web Folder Contain all the required file to run website in local host.
The password for all user is gundam and you can look username at SQL database.
\Project Works\Web\k1429795\www   path contain all the php and html file needed for the website to run
