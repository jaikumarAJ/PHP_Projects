<?php

namespace StatsBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class StatsBundle extends Bundle
{
}
