<?php

namespace AnnuaireBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class AnnuaireBundle extends Bundle
{
}
