<?php

namespace Acme\GlobalBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class GlobalBundle extends Bundle
{
}
