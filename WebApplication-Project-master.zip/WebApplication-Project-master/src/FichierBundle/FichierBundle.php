<?php

namespace FichierBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class FichierBundle extends Bundle
{
}
